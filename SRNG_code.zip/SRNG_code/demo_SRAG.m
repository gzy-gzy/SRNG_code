% The code is written by Zhanxuan Hu
% The code is partially based on Low-Rank Representation with Adaptive Graph
% Regularization.
clear all
clc
clear memory;
name = 'YaleB_32x32';

% pamrameter
selected_class = 8;
lambda1 = 2e-2;
lambda2 = 2e-1;

% load data
load(name)
fea = double(fea);
nnClass = length(unique(gnd));     % The number of classes
select_sample = [];
select_gnd    = [];
for i = 1:selected_class
    idx = find(gnd == i);
    idx_sample    = fea(idx,:);
    select_sample = [select_sample;idx_sample];
    select_gnd    = [select_gnd;gnd(idx)];
end
    
fea = select_sample';
fea = fea./repmat(sqrt(sum(fea.^2)),[size(fea,1) 1]);
gnd = select_gnd;
c   = selected_class;

X = fea;
clear fea select_gnd select_sample idx
[m,n] = size(X);

% ---------- initilization for Z and F -------- %
options = [];
options.NeighborMode = 'KNN';
options.k = 10;
options.WeightMode = 'Binary';      % Binary  HeatKernel
Z = constructW(X',options);
Z = full(Z);
Z1 = Z-diag(diag(Z));         
Z = (Z1+Z1')/2;
Z_ini = Z;
clear LZ DZ Z fea Z1

max_iter= 80;
Ctg = inv(X'*X+2*eye(size(X,2)));
tic
[Z,S,U,E] = SRAG(X,Z_ini,c,lambda1,lambda2,max_iter,Ctg);
toc
addpath('Ncut_9');
Z_out = Z;
A = Z_out;
A = A - diag(diag(A));
A = (A+A')/2;  
[NcutDiscrete,NcutEigenvectors,NcutEigenvalues] = ncutW(A,c);
[value,result_label] = max(NcutDiscrete,[],2);
result = ClusteringMeasure(gnd, result_label)